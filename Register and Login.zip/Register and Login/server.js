const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const port = 3000;


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect('mongodb+srv://meisuenn:password%40123@cluster0.krxkuxp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}); 

// Create a User model
const User = mongoose.model('users', {
  username: String,
  password: String,
});

// Serve registration form
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'register.html'));
});

// Serve login form
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Serve change password form
app.get('/changepassword', (req, res) => {
  res.sendFile(path.join(__dirname, 'changepassword.html'));
});

// Handle registration
app.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Hash the password before saving to the database
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const user = new User({ username, password: hashedPassword });
    
    // Log user information
    console.log('User attempting to register:', user);

    await user.save();

    // Log successful registration
    console.log('User registered successfully:', user);

    res.send('Registration successful!');
  } catch (error) {
    // Log registration error
    console.error('Error during registration:', error);
    res.status(500).send('Error during registration.');
  }
});

// Handle login
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (user && await bcrypt.compare(password, user.password)) {
      res.send('Login successful!');
    } else {
      res.status(401).send('Invalid credentials.');
    }
  } catch (error) {
    res.status(500).send('Error during login.');
  }
});

// Handle change password
app.post('/changepassword', async (req, res) => {
  try {
    const { username, oldPassword, newPassword, confirmNewPassword } = req.body;
    console.log('Received data:', { username, oldPassword, newPassword, confirmNewPassword });

    const user = await User.findOne({ username });

    if (!user) {
      return res.status(404).send('User not found.');
    }

    if (!(await bcrypt.compare(oldPassword, user.password))) {
      return res.status(401).send('Invalid old password.');
    }

    if (newPassword !== confirmNewPassword) {
      return res.status(400).send('New password and confirm new password do not match.');
    }

    // Ensure newPassword and user.password are valid strings
    const isValidString = (str) => typeof str === 'string' && str.trim().length > 0;

    if (!isValidString(newPassword) || !isValidString(user.password)) {
      return res.status(500).send('Invalid data for password change.');
    }

    // Hash the new password before updating
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    // Send a redirect response to the login page
    res.redirect('/login');
  } catch (error) {
    console.error('Error during password change:', error);
    res.status(500).send(`Error during password change: ${error.message}`);
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
